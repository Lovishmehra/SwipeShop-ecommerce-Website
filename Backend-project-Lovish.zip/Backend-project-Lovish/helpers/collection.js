module.exports={
   COLLECTION_NAME:"Product",
   userCollection:"users",
   cartCollection:"usercart"

}